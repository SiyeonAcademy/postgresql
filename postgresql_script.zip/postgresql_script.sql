--7.3 세션 모니터링 
select 
      datname 
    , pid 
    , pg_blocking_pids(pid) as holder
    , substr(query, 1, 14) as query
    , state
    , extract(epoch from current_timestamp - query_start)::integer as querytime 
    , extract(epoch from current_timestamp - xact_start)::integer as txntime 
    , usename 
    , application_name 
    , wait_event_type 
    , wait_event 
from  pg_stat_activity 
where state in ('active', 'idle in transaction') 
and pid not in (select pg_backend_pid()) 
order by 6 desc;

--7.5 IO 모니터링
select 
      backend_type
    , object
    , context
    , round((rtime + wtime) / 1000, 1) as iotime_s
    , round((rtime + wtime) / sum(rtime + wtime) over() * 100, 1) as "pct(%)"
    , round(rtime / 1000, 1) as rtime_s
    , round(wtime / 1000, 1) as wtime_s
    , (reads + writes) as totio
    , round((reads + writes) / sum(reads + writes) over() * 100, 1) as "pct(%)"
    , reads
    , writes
from (
    select 
          backend_type
        , object
        , context
        , coalesce(read_time::numeric, 0)  as rtime
        , coalesce(write_time::numeric, 0) as wtime
        , coalesce(reads, 0)  as reads
        , coalesce(writes, 0) as writes
    from pg_stat_io
) t
order by 4 desc;

--7.6 복제 모니터링 
select 
      pid 
    , application_name
    , client_addr
    , pg_size_pretty(pg_wal_lsn_diff(pg_current_wal_lsn(), sent_lsn))   as send_lag_sz
    , pg_size_pretty(pg_wal_lsn_diff(sent_lsn,  write_lsn))             as write_lag_sz
    , pg_size_pretty(pg_wal_lsn_diff(write_lsn, flush_lsn))             as flush_lag_sz
    , pg_size_pretty(pg_wal_lsn_diff(flush_lsn, replay_lsn))            as replay_lag_sz
    , pg_size_pretty(pg_wal_lsn_diff(pg_current_wal_lsn(), replay_lsn)) as total_lag_sz
    , write_lag                      as write_lag_time
    , flush_lag - write_lag          as flush_lag_time
    , replay_lag - flush_lag         as replay_lag_time
    , replay_lag                     as total_lag_time
from  pg_stat_replication;

--7.7 작업 진행 상황 모니터링
--인덱스 생성 진행 상황 모니터링 
select 
    a.pid
  , b.query
  , extract(epoch from current_timestamp - b.query_start)::integer as runtime
  , a.command
  , a.phase 
  , a.blocks_total
  , a.blocks_done
  , round((blocks_done::numeric / (case when blocks_total = 0 then 1 else blocks_total end) * 100.0), 1) as blk_scan_ratio
  , a.tuples_total 
  , a.tuples_done 
  , round((tuples_done::numeric / (case when tuples_total = 0 then 1 else tuples_total end) * 100.0), 1) as tup_scan_ratio
  , b.wait_event  
  , b.wait_event_type 
  , pg_blocking_pids(b.pid) as holder
from pg_stat_progress_create_index a
   , pg_stat_activity b
where a.pid = b.pid;

--Vacuum 진행 상황 모니터링
select 
    b.pid
  , b.query
  , extract(epoch from current_timestamp - b.query_start)::integer as runtime
  , round((heap_blks_scanned * 100.0 / heap_blks_total), 1)  as scan_ratio
  , round((heap_blks_vacuumed * 100.0 / heap_blks_total), 1) as vacuum_ratio
  , a.index_vacuum_count 
  , a.phase 
  , a.heap_blks_total 
  , a.heap_blks_scanned  
  , a.heap_blks_vacuumed  
  , pg_size_pretty(a.max_dead_tuple_bytes) as max_dead_tuple_sz
  , pg_size_pretty(a.dead_tuple_bytes) as dead_tuple_sz
  , a.num_dead_item_ids
  , a.indexes_total 
  , a.indexes_processed
  , b.wait_event  
  , b.wait_event_type 
  , pg_blocking_pids(b.pid) as holder
from pg_stat_progress_vacuum a
   , pg_stat_activity b 
where a.pid = b.pid;

--Vacuum Full 진행 상황 모니터링 
select 
       b.pid
     , b.query 
     , extract(epoch from current_timestamp - b.query_start)::integer as runtime
     , round((heap_blks_scanned * 100.0 / heap_blks_total), 1) as scan_ratio
     , a.phase
     , a.heap_tuples_scanned 
     , a.heap_blks_scanned 
     , a.heap_tuples_written
     , a.heap_blks_total
     , a.index_rebuild_count
     , b.wait_event  
     , b.wait_event_type 
     , pg_blocking_pids(b.pid) as holder
from   pg_stat_progress_cluster a
     , pg_stat_activity b 
where  a.pid = b.pid;

--COPY 진행 상황 모니터링
select 
      b.pid
    , b.query 
    , extract(epoch from current_timestamp - b.query_start)::integer as runtime
    , case when a.command = 'COPY FROM' and bytes_total > 0 
           then round((bytes_processed * 100.0 / bytes_total), 1)
      end as copy_from_ratio				  
    , case when a.command = 'COPY TO'
           then round((a.tuples_processed * 100.0
                       / (select reltuples 
                            from pg_class 
                           where oid = a.relid))::numeric, 1)
      end as copy_to_ratio
    , a.command
    , a.bytes_processed 
    , a.bytes_total 
    , a.tuples_processed
    , a.tuples_skipped
    , b.wait_event  
    , b.wait_event_type 
    , pg_blocking_pids(b.pid) as holder
from  pg_stat_progress_copy a
    , pg_stat_activity b 
where a.pid = b.pid;
